BROWN'S ALBUM MVP

Already connected to your Supabase project.

FEATURES
- Public album browsing
- Album search
- All Photos
- Favorites
- Full-screen viewer
- Swipe left/right
- Double-tap zoom
- Share photo
- Admin email/password login
- Create/delete albums
- Upload/delete multiple photos
- iPhone Home Screen PWA

DEPLOY FROM IPHONE
Use Netlify Drop or another HTTPS static host.
Upload the contents of this ZIP, not the ZIP itself if the host asks for a folder.

AFTER DEPLOYMENT
1. Open the public URL in Safari.
2. Tap the gear icon.
3. Sign in with your Supabase admin email/password.
4. Create an album and upload photos.
5. Safari Share > Add to Home Screen.

APP STORE
This PWA is the working MVP. Apple App Store submission still requires native wrapping/building,
Apple Developer membership, signing, screenshots, privacy policy, and App Review.

ADMIN LINK
https://brownsluxury.com/admin
Sign in with your Supabase admin email and password.
