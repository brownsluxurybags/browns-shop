window.APP_CONFIG = {
  SUPABASE_URL: "https://rgfsqdnllnfaqbrmbfse.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_5l7uhVjjI9PpUFk8RI0YTg_dpsrQbUd",
  STORAGE_BUCKET: "product-images"
};